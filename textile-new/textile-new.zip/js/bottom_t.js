/**
 * Created by Administrator on 2017/8/29.
 */
// JavaScript Document
document.write('<div class="w">');
document.write('<div class="bottom_t_logo">');
document.write('<img src="images/u188.png" alt="logo">');
document.write('</div>');
document.write('<div class="lj">');
document.write('<ul>');
document.write('<li class="set_font"><a href="javascript:;">����</a></li>');
document.write('<li><a href="javascript:;">�½�</a></li>');
document.write('<li><a href="javascript:;">��֯</a></li>');
document.write('<li><a href="javascript:;">�޸�</a></li>');
document.write('<li><a href="javascript:;">ͼƬ</a></li>');
document.write('</ul>');
document.write('<ul>');
document.write('<li class="set_font"><a href="javascript:;">����</a></li>');
document.write('<li><a href="javascript:;">CNCE</a></li>');
document.write('<li><a href="javascript:;">����</a></li>');
document.write('<li><a href="javascript:;">�ڻ�</a></li>');
document.write('<li><a href="javascript:;">��Ƶ</a></li>');
document.write('</ul>');
document.write('<ul>');
document.write('<li class="set_font"><a href="javascript:;">�۸�</a></li>');
document.write('<li><a href="javascript:;">��������</a></li>');
document.write('<li><a href="javascript:;"></a></li>');
document.write('<li class="set_font"><a href="javascript:;">ͳ��</a></li>');
document.write('<li><a href="javascript:;">��������</a></li>');
document.write('</ul>');
document.write('<ul>');
document.write('<li class="set_font"><a href="javascript:;">���޾���</a></li>');
document.write('<li><a href="javascript:;">���䲹��</a></li>');
document.write('<li><a href="javascript:;"></a></li>');
document.write('<li class="set_font"><a href="javascript:;">�ֻ�����</a></li>');
document.write('<li><a href="javascript:;">ҵ��ר��</a></li>');
document.write('</ul>');
document.write('<ul>');
document.write('<li class="set_font"><a href="javascript:;">�����б�</a></li>');
document.write('<li><a href="javascript:;">����</a></li>');
document.write('<li><a href="javascript:;">���ר��</a></li>');
document.write('<li><a href="javascript:;">��Ʒ����</a></li>');
document.write('<li><a href="javascript:;">��Ϣ�ɼ�</a></li>');
document.write('<li><a href="javascript:;">ָ������</a></li>');
document.write('</ul>');
document.write('</div>');
document.write('<div class="address">');
document.write('<div class="cf"><i class="iph"></i><span>010-88086622</span></div>');
document.write('<div class="cf"><i class="email"></i><span>info@cottonchina.org</span></div>');
document.write('<div class="cf l_h"><i class="coordinate"></i><span>���������������������ּ�1�Ż����Ѷ����A5</span></div>');
document.write('<div class="find_s">');
document.write('<form>')
document.write('<input type="text" value="����ؼ���" onfocus="if(value==\'����ؼ���\') {value=\'\';this.style.color=\'#333333\'}" onblur="if (value==\'\') {value=\'����ؼ���\';this.style.color=\'#999999\'}">');
document.write('<button><i class="find"></i></button>');
document.write('<form>')
document.write('</div>');
document.write('</div>');
document.write('</div>');