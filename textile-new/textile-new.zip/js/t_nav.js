/**
 * Created by Administrator on 2017/8/29.
 */
// JavaScript Document
document.write('<div class="t_nav">')
document.write('<div class="w">');
document.write('<ul class="ul_left">');
document.write('<li><a href="http://www.cnce.com" target="_blank">CNCE����</a></li>');
document.write('<li><a href="http://www.cottoneasy.com" target="_blank">e����</a></li>');
document.write('<li><a href="http://www.i-cotton.org" target="_blank">i����</a></li>');
document.write('<li><a href="http://www.cncexj.com" target="_blank">�½�����޻���</a></li>');
document.write('</ul>');
document.write('<ul class="ul_right">');
document.write('<li><a href="javascript:;">ע��</a></li>');
document.write('<li><a href="javascript:;">��½</a></li>');
document.write('<li><a href="javascript:;"><i class="weibo"></i></a></li>');
document.write('<li><a href="javascript:;"><i class="weixin"></i></a></li>');
document.write('<li><a href="javascript:;">������Ա</a></li>');
document.write('<li><a href="javascript:;">��վ��ͼ</a></li>');
document.write('</ul>');
document.write('</div>');
document.write('</div>');
document.write('<div class="b_nav">');
document.write('<div class="w">');
document.write('<ul class="cf">');
document.write('<li><a href="javascript:;">��ҳ<span>��|</span></a></li>');
document.write('<li><a href="javascript:;">�����б�<span>��|</span></a></li>');
document.write('<li><a href="javascript:;">����<span>��|</span></a></li>');
document.write('<li><a href="javascript:;">����<span>��|</span></a></li>');
document.write('<li><a href="javascript:;">��֯<span>��|</span></a></li>');
document.write('<li><a href="javascript:;">�½�<span>��|</span></a></li>');
document.write('<li><a href="javascript:;">�޸�<span>��|</span></a></li>');
document.write('<li><a href="javascript:;">�ڻ�<span>��|</span></a></li>');
document.write('<li><a href="javascript:;">�۸�<span>��|</span></a></li>');
document.write('<li><a href="javascript:;">ͳ��<span>��|</span></a></li>');
document.write('<li><a href="javascript:;">��Ƶ<span>��|</span></a></li>');
document.write('<li><a href="javascript:;">����<span>��|</span></a></li>');
document.write('<li><a href="javascript:;">Engish</a></li>');
document.write('</ul>');
document.write('</div>');
document.write('</div>');